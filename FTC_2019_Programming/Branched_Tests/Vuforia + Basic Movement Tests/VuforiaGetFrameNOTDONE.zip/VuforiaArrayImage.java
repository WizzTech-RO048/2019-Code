package org.firstinspires.ftc.teamcode;


import java.nio.ByteBuffer;

public class VuforiaArrayImage {
    private ByteBuffer cameraImage;
    private int height;
    private int width;

    public VuforiaArrayImage(ByteBuffer cameraImage, int height, int width) {
        this.cameraImage = cameraImage;
        this.height = height;
        this.width = width;
    }

    public ByteBuffer getCameraImage() {
        return cameraImage;
    }

    public int getHeight() {
        return height;
    }

    public int getWidth() {
        return width;
    }
}
