package org.firstinspires.ftc.teamcode;

import com.vuforia.Frame;
import com.vuforia.Image;
import com.vuforia.PIXEL_FORMAT;
import com.vuforia.Vuforia;

import org.firstinspires.ftc.robotcore.external.Telemetry;
import org.firstinspires.ftc.robotcore.external.navigation.VuforiaLocalizer;

import java.nio.ByteBuffer;

import static com.vuforia.Vuforia.init;

public class VuforiaFrameAnalysis extends Vuforia_Navigation{

    private Initialisation init;
    private VuforiaLocalizerImplSubclass vuforia1;

    VuforiaFrameAnalysis(Initialisation init) {
        this.init = init;
        init();
    }


    public VuforiaArrayImage getImage(Telemetry telemetry, Image rgb) {
        /** VUFORIA GET LAST IMAGE ON SCREEN


         /*To access the image: you need to iterate through the images of the frame object:*/

        /*if (vuforia != null) {
            telemetry.addData(">", ".");
            telemetry.update();

            ByteBuffer cameraImage = rgb.getPixels();
            int height = rgb.getBufferHeight();
            int width = rgb.getBufferWidth();

            return new VuforiaArrayImage(cameraImage, height, width);
        }*/
        return null;
    }

    public void processFrame(Frame frame) {
        /*if (frame != null) {

            bitmap = convertFrameToBitmap(frame);

            inputMat = new Mat(bitmap.getWidth(), bitmap.getHeight(), CvType.CV_8UC1);
            Utils.bitmapToMat(bitmap, inputMat);

            outMat = detector.processFrame(inputMat, null);

            if (showDebug) {
                if (loadedTrackableSets != null && loadedTrackableSets.size() > 0) {
                    VuforiaTrackablesImpl trackables = loadedTrackableSets.get(0);
                    int count = 0;
                    for (VuforiaTrackable trackable : trackables) {
                        if (trackable == null || ((VuforiaTrackableDefaultListener) trackable.getListener()) == null) {
                            continue;
                        }
                        if (((VuforiaTrackableDefaultListener) trackable.getListener()).isVisible()) {
                            Imgproc.putText(outMat, "Vuforia: " + trackable.getName(), new Point(10, 50 * count + 50), 0, 2, new Scalar(0, 255, 0), 3);
                            count++;
                        }

                    }
                }

            }


            if (!outMat.empty()) {

                bitmap.setHeight(outMat.height());
                bitmap.setWidth(outMat.width());
                Utils.matToBitmap(outMat, bitmap);


                //height = <user-chosen width> * original height / original width
                double adjustedHieght = displayView.getWidth() * outMat.height() / outMat.width();
                outputImage = Bitmap.createScaledBitmap(bitmap, displayView.getWidth(), (int) adjustedHieght, false);

                ((Activity) displayView.getContext()).runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        displayView.onFrame(outputImage);
                        displayView.invalidate();
                    }
                });

            } else {
                Log.w("DogeCV", "MAT BITMAP MISMATCH OR EMPTY ERROR");
            }


            inputMat.release();
            outMat.release();


        } else {
            Log.d("DogeCV", "No Frame!");
        }*/
    }
}
