package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.vuforia.Image;

@Autonomous(name = "AdaptedConcept: Vuforia Nav", group = "Testing")
public class Vuforia_Navigation extends LinearOpMode {

    @Override
    public void runOpMode() {
        Initialisation init = new Initialisation(hardwareMap);
        //VuforiaFrameAnalysis frameAnalysis;

        init.initVuforia();
        init.init();       //Initializare robot --- momentan gol

        //frameAnalysis = new VuforiaFrameAnalysis(init);

        telemetry.addData(">", "Press Play to start");
        telemetry.update();

        waitForStart();

        init.activate();    //Activeaza Vuforia Navigation---aici incepe vuforia sa primeasca date de la camera

        while (opModeIsActive()) {
            VuforiaArray vArray = init.locationVuforia();       //Array ce contine locatia
            telemetry.addData(">", "x %f,y %f,z %f,r %f,p %f,h %f", vArray.getX(), vArray.getY(), vArray.getZ(), vArray.getRoll(), vArray.getPitch(), vArray.getHeading());
            //VuforiaArrayImage arrayImage = frameAnalysis.getImage(telemetry, rgb);
            //telemetry.addData("<", " Height: %d - Width: %d - Byte %d", arrayImage.getHeight(), arrayImage.getWidth(), arrayImage.getCameraImage().getInt(1)); //wrong type
            telemetry.update();
        }
    }
}
