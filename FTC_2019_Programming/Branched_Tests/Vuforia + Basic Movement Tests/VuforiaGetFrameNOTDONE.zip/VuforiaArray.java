package org.firstinspires.ftc.teamcode;


public class VuforiaArray {
    private float x, y, z, roll, pitch, heading;

    public VuforiaArray(float x, float y, float z, float roll, float pitch, float heading) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.roll = roll;
        this.pitch = pitch;
        this.heading = heading;
    }

    public float getHeading() {
        return heading;
    }

    public float getPitch() {
        return pitch;
    }

    public float getRoll() {
        return roll;
    }

    public float getY() {
        return y;
    }

    public float getZ() {
        return z;
    }

    public float getX() {
        return x;
    }
}
